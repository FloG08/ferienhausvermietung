<?php
require dirname(__DIR__) . '/connect/connect.php';

// Prüfen, ob die ID über die URL übergeben wurde
if (isset($_GET['deleteID'])) {
    $id = intval($_GET['deleteID']); // ID als Integer um sicherzustellen, dass es eine Zahl ist

    try {
        // Transaktion starten
        $pdo->beginTransaction();

        // Löschen der zugehörigen Daten aus der 'verleih' Tabelle
        $stmt = $pdo->prepare('DELETE FROM buchung WHERE id = :id');
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        // Löschen des Kunden-Eintrags aus der 'kunden' Tabelle
        $stmt = $pdo->prepare('DELETE FROM buchung WHERE id = :id');
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();

        // Transaktion abschließen
        $pdo->commit();

        // Nach dem Löschen auf die Hauptseite weiterleiten
        header("Location: buchung.php?success=1");
        exit;
    } catch (PDOException $e) {
        // Fehlerbehandlung bei Problemen
        $pdo->rollBack();
        die("Fehler beim Löschen: " . $e->getMessage());
    }
} else {
    // Falls keine ID übergeben wurde, Weiterleitung zur Hauptseite
    header("Location: buchung.php?error=1");
    exit;
}
?>
